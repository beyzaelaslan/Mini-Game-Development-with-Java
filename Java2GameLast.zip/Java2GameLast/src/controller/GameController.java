package controller;

import model.GameModel;
import view.GameView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameController {
    private GameModel model;
    private GameView view;

    public GameController(GameModel model, GameView view) {
        this.model = model;
        this.view = view;
        addControlListeners();
        view.updateView();
    }

    private void addControlListeners() {
        view.getUpButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.moveHand(-1, 0);
                view.updateView();
            }
        });

        view.getDownButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.moveHand(1, 0);
                view.updateView();
            }
        });

        view.getLeftButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.moveHand(0, -1);
                view.updateView();
            }
        });

        view.getRightButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.moveHand(0, 1);
                view.updateView();
            }
        });
    }
}