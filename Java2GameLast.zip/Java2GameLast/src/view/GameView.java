package view;

import model.GameModel;
import javax.swing.*;
import java.awt.*;

public class GameView extends JPanel {
    private GameModel model;
    private JButton[][] gridButtons = new JButton[GameModel.GRID_SIZE][GameModel.GRID_SIZE];
    private JLabel scoreLabel;
    private JButton upButton, downButton, leftButton, rightButton;


    public static final int GRID_SIZE = 10;
    public GameView(GameModel model) {
        this.model = model;
        initialize();

    }

    private void initialize() {
        setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(GRID_SIZE, GRID_SIZE));
        gridButtons = new JButton[GRID_SIZE][GRID_SIZE];

        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                gridButtons[i][j] = new JButton();
                gridPanel.add(gridButtons[i][j]);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

        scoreLabel = new JLabel("Score: 0");
        add(scoreLabel, BorderLayout.SOUTH);

        JPanel controlPanel = new JPanel();
        upButton = new JButton("Up");
        downButton = new JButton("Down");
        leftButton = new JButton("Left");
        rightButton = new JButton("Right");

        controlPanel.add(upButton);
        controlPanel.add(downButton);
        controlPanel.add(leftButton);
        controlPanel.add(rightButton);

        add(controlPanel, BorderLayout.NORTH);
    }

    public void updateView() {
        for (int i = 0; i < GameModel.GRID_SIZE; i++) {
            for (int j = 0; j < GameModel.GRID_SIZE; j++) {
                if (model.getHandPosition().equals(new Point(i, j))) {
                    gridButtons[i][j].setFont(new Font("Hand Emoji", Font.PLAIN, 24)); // Set font to Apple Color Emoji
                    gridButtons[i][j].setText("\uD83D\uDC4B"); // Unicode for "Hand" emoji
                } else {
                    gridButtons[i][j].setFont(new Font("Apple Color Emoji", Font.PLAIN, 24)); // Set font to Apple Color Emoji
                    gridButtons[i][j].setText(model.isAppleAt(i, j) ? "\uD83C\uDF4E" : ""); // Unicode for "Apple" emoji
                }
            }
        }
        scoreLabel.setText("Score: " + model.getScore());
    }

    public JButton getUpButton() { return upButton; }
    public JButton getDownButton() { return downButton; }
    public JButton getLeftButton() { return leftButton; }
    public JButton getRightButton() { return rightButton; }
}
