package model;

import javax.swing.*;
import java.awt.Point;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GameModel {
    public static final int GRID_SIZE = 6;
    private Point handPosition;
    private boolean[][] apples;
    private int score;



    public GameModel() {
        handPosition = new Point(0, 0);
        apples = new boolean[GRID_SIZE][GRID_SIZE];
        placeApples();


    }

    private void placeApples() {
        Random random = new Random();
        Set<Point> placedApples = new HashSet<>();

        while (placedApples.size() < GRID_SIZE) {
            int x = random.nextInt(GRID_SIZE);
            int y = random.nextInt(GRID_SIZE);
            Point applePoint = new Point(x, y);
            if (placedApples.add(applePoint)) {
                apples[x][y] = true;
            }
        }
    }

    public Point getHandPosition() {
        return handPosition;
    }

    public boolean isAppleAt(int x, int y) {
        return apples[x][y];
    }

    public int getScore() {
        return score;
    }

    public void moveHand(int dx, int dy) {
        int newX = handPosition.x + dx;
        int newY = handPosition.y + dy;

        if (newX >= 0 && newX < GRID_SIZE && newY >= 0 && newY < GRID_SIZE) {
            handPosition.setLocation(newX, newY);

            if (apples[newX][newY]) {
                apples[newX][newY] = false;
                score += 100;

                if (areAllApplesEaten()) {
                    // Create a timer to delay the message by 3 seconds
                    Timer timer = new Timer(200, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            JOptionPane.showMessageDialog(null, "Congratulations! You have eaten all the apples.", "Success", JOptionPane.INFORMATION_MESSAGE);
                            System.exit(0);
                        }
                    });
                    timer.setRepeats(false); // Set the timer to run only once
                    timer.start(); // Start the timer
                }
            }
        }
    }

    public boolean areAllApplesEaten() {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                if (apples[i][j]) {
                    return false; // If any apple is found, return false
                }
            }
        }

        return true; // If no apple is found, return true
    }





}
